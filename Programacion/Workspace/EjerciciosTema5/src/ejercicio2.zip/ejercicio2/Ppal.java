package ejercicio2;
import java.util.ArrayList;
public class Ppal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Socio Socio1 = new Socio("53353047Q","Carlos Mesquita Mansilla");
		Socio Socio2 = new Socio("11111111A","Pepito Prevenciones Garc�a");
		Socio Socio3 = new Socio("22222222B","Benito Torres");
	}

}
