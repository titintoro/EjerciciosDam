package prueba01;

public interface IEstudiable {

	
}
