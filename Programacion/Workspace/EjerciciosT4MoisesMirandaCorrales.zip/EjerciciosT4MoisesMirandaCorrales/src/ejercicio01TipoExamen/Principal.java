package ejercicio01TipoExamen;

public class Principal {

	public static void main(String[] args) {
		
		Habitacion h1 = new Habitacion (100, false, "1",2,5);
		Habitacion h2 = new Suite (150, true, "2",10,2,120,50);
		Habitacion h3 = new Apartamento (60, false, "3",7,1, true);
		
		Habitacion lista [] = {h1,h2,h3};
		
		GestionHabitaciones h = new GestionHabitaciones(lista);
		
		int numlista = 1;
		double descuento = 15;
		
			
		System.out.println(h.calcularRecaudacionTotal(descuento));
		h.mostrarFactura(numlista, descuento);
		
		
	}

}
