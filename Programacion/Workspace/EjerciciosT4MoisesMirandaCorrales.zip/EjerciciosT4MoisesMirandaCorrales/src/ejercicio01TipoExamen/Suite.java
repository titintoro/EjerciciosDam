package ejercicio01TipoExamen;

public class Suite extends Habitacion {
	
	private double mcuadrados;
	private double gastadoServHabit; //cantidad de dinero consumido en servicio de habitaciones.
	
	public Suite(double precioB, boolean ocupada, String numCliente, int diasOcupacion, int numOcupantes,
			double mcuadrados, double gastadoServHabit) {
		super(precioB, ocupada, numCliente, diasOcupacion, numOcupantes);
		this.mcuadrados = mcuadrados;
		this.gastadoServHabit = gastadoServHabit;
	}

	public double getMcuadrados() {
		return mcuadrados;
	}

	public void setMcuadrados(double mcuadrados) {
		this.mcuadrados = mcuadrados;
	}

	public double getGastadoServHabit() {
		return gastadoServHabit;
	}

	public void setGastadoServHabit(double gastadoServHabit) {
		this.gastadoServHabit = gastadoServHabit;
	}

	@Override
	public String toString() {
		return "Suite [mcuadrados=" + mcuadrados + ", gastadoServHabit=" + gastadoServHabit + "]";
	}
	
	public double calcularPrecio (double descuento) {
		int den = 100;
		return super.calcularPrecio(descuento) + gastadoServHabit - ((super.calcularPrecio(descuento) + 
				gastadoServHabit) * descuento / den);
	}
	
	
	
	
	
}
