package ejercicio01TipoExamen;

import java.util.Arrays;

public class GestionHabitaciones {
	
	private Habitacion[] lista;
	
	public GestionHabitaciones(Habitacion[] lista) {
		super();
		this.lista = lista;
	}
	
	public GestionHabitaciones() {
		lista=new Habitacion[4];
	}


	public Habitacion[] getLista() {
		return lista;
	}


	public void setLista(Habitacion[] lista) {
		this.lista = lista;
	}


	@Override
	public String toString() {
		return "GestionHabitaciones [lista=" + Arrays.toString(lista) + "]";
	}


	public double calcularPrecioHabitacion (int numlista, double descuento) {
		
		return lista [numlista-1].calcularPrecio(descuento);
	}
	
	public double calcularPrecioHabitacion (Habitacion h,double descuento) {
		
		return h.calcularPrecio(descuento);
	}
	
	public double calcularRecaudacionTotal (double descuento) {
		double sumalista = 0;
		for (int i = 0; i < lista.length; i++) {
			if(lista[i].isOcupada()) {
				sumalista = sumalista + calcularPrecioHabitacion(lista[i], descuento);
			}
			
		}
		return sumalista;
	}
	
	public void mostrarFactura (int numlista, double descuento) {
		System.out.println("\t\t\t HOTEL SALESIANO");
		System.out.println("------------------------------------------------");
		System.out.println("Precio Base = " + lista [numlista].getPrecioB());
		System.out.println("N�mero de Cliente = " + lista [numlista].getNumCliente());
		System.out.println("D�as de Ocupaci�n = " + lista [numlista].getDiasOcupacion());
		System.out.println("N�mero de ocupantes = " + lista [numlista].getNumOcupantes());
		System.out.println("Precio de la Habitaci�n = " + calcularPrecioHabitacion(numlista, descuento));
		
	}
	
	public void mostrarNoOcupadas () {
		
		for (int i = 0; i < lista.length; i++) {
			if (lista [i].isOcupada() == false) {
				System.out.println(lista [i].toString());
			}
		}
	}
	
}

