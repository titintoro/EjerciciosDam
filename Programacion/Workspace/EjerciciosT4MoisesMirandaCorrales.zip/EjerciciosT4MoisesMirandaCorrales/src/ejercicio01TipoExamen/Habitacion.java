package ejercicio01TipoExamen;

public class Habitacion {
	
	private double precioB;
	private boolean ocupada;
	private String numCliente;
	private int diasOcupacion;
	private int numOcupantes;
	
	public Habitacion(double precioB, boolean ocupada, String numCliente, int diasOcupacion, int numOcupantes) {
		super();
		this.precioB = precioB;
		this.ocupada = ocupada;
		this.numCliente = numCliente;
		this.diasOcupacion = diasOcupacion;
		this.numOcupantes = numOcupantes;
	}

	public double getPrecioB() {
		return precioB;
	}

	public void setPrecioB(double precioB) {
		this.precioB = precioB;
	}

	public boolean isOcupada() {
		return ocupada;
	}

	public void setOcupada(boolean ocupada) {
		this.ocupada = ocupada;
	}

	public String getNumCliente() {
		return numCliente;
	}

	public void setNumCliente(String numCliente) {
		this.numCliente = numCliente;
	}

	public int getDiasOcupacion() {
		return diasOcupacion;
	}

	public void setDiasOcupacion(int diasOcupacion) {
		this.diasOcupacion = diasOcupacion;
	}

	public int getNumOcupantes() {
		return numOcupantes;
	}

	public void setNumOcupantes(int numOcupantes) {
		this.numOcupantes = numOcupantes;
	}

	@Override
	public String toString() {
		return "Habitacion [precioB=" + precioB + ", ocupada=" + ocupada + ", numCliente=" + numCliente
				+ ", diasOcupacion=" + diasOcupacion + ", numOcupantes=" + numOcupantes + "]";
	}
	
	
	public double calcularPrecio (double descuento) {
		return precioB * diasOcupacion;
	}

}
