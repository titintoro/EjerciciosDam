package ejercicio01TipoExamen;

public class Apartamento extends Habitacion {
	
	private boolean ServLimpieza;

	public Apartamento(double precioB, boolean ocupada, String numCliente, int diasOcupacion, int numOcupantes,
			boolean servLimpieza) {
		super(precioB, ocupada, numCliente, diasOcupacion, numOcupantes);
		ServLimpieza = servLimpieza;
	}

	public boolean isServLimpieza() {
		return ServLimpieza;
	}

	public void setServLimpieza(boolean servLimpieza) {
		ServLimpieza = servLimpieza;
	}

	@Override
	public String toString() {
		return "Apartamento [ServLimpieza=" + ServLimpieza + "]";
	}
	
	
	public double calcularPrecio (double descuento, double pServLimpieza) {
		
		if (ServLimpieza == true) {
			return super.calcularPrecio(descuento) + pServLimpieza;
		}else {
			return super.calcularPrecio(descuento);
		}
		
	}

}
