package ejercicio03;

public class Motocicleta extends Vehiculo {

	public Motocicleta(double cilindrada, int caballos, String combustible) {
		super(cilindrada, caballos, combustible);
	}

	@Override
	public String toString() {
		return "Motocicleta [getCilindrada()=" + getCilindrada() + ", getCaballos()=" + getCaballos()
				+ ", getCombustible()=" + getCombustible() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
	public double CalcularImpuestoCirculacion (double fija,double porPotencia, double porCilindrada, double impFurgonetas) {
		
		int den=100;
		
		return super.CalcularImpuestoCirculacion(fija, porPotencia, porCilindrada, impFurgonetas) + (getCaballos() * porPotencia / den);
	}
	
	

}
