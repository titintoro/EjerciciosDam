package ejercicio03;

public class Furgoneta extends Vehiculo {

	public Furgoneta(double cilindrada, int caballos, String combustible) {
		super(cilindrada, caballos, combustible);
	}

	@Override
	public String toString() {
		return "Furgoneta [getCilindrada()=" + getCilindrada() + ", getCaballos()=" + getCaballos()
				+ ", getCombustible()=" + getCombustible() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
	public double CalcularImpuestoCirculacion (double fija,double porPotencia, double porCilindrada, double impFurgonetas) {
		
		return fija + impFurgonetas;
	}
}
