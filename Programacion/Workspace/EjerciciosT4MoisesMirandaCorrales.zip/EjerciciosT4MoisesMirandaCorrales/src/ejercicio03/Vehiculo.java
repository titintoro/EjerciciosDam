package ejercicio03;

public class Vehiculo {
	
	private double cilindrada;
	private int caballos;
	private String combustible;
	
	public Vehiculo(double cilindrada, int caballos, String combustible) {
		super();
		this.cilindrada = cilindrada;
		this.caballos = caballos;
		this.combustible = combustible;
	}

	public double getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(double cilindrada) {
		this.cilindrada = cilindrada;
	}

	public int getCaballos() {
		return caballos;
	}

	public void setCaballos(int caballos) {
		this.caballos = caballos;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}

	@Override
	public String toString() {
		return "Vehiculo [cilindrada=" + cilindrada + ", caballos=" + caballos + ", combustible=" + combustible + "]";
	}
	
	
	public double CalcularImpuestoCirculacion (double fija,double porPotencia, double porCilindrada, double impFurgonetas) {
	
		return fija;
	}
	
	

}
