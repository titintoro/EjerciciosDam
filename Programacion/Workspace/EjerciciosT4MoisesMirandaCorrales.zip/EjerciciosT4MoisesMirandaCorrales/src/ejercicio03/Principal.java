package ejercicio03;

public class Principal {

	public static void main(String[] args) {
		
		
		Coche c = new Coche (1.1, 120, "Sin plomo");
		
		Motocicleta m = new Motocicleta (1.6, 49, "Diesel");
		
		Furgoneta f = new Furgoneta (2.5, 140, "Diesel");
		
		double fija = 70, porPotencia = 60, porCilindrada = 25, impFurgonetas = 60;
		
		
		
		System.out.println("El precio del impuesto del coche es de " + 
		c.CalcularImpuestoCirculacion(fija, porPotencia, porCilindrada, impFurgonetas) + " �");
		
		System.out.println("El precio del impuesto de la motocicleta es de " + 
		m.CalcularImpuestoCirculacion(fija, porPotencia, porCilindrada, impFurgonetas) + " �");
		
		System.out.println("El precio del impuesto de la furgoneta es de " +
		f.CalcularImpuestoCirculacion(fija, porPotencia, porCilindrada, impFurgonetas) + " �");

	}

}
