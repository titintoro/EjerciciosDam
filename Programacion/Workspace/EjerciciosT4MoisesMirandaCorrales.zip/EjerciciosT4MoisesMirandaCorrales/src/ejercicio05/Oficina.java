package ejercicio05;

public class Oficina {
	
	public double calcularSueldoEmpleado (Empleado e) {
		return e.calcularSueldo();
	}
	
	public double sumarSueldos(Empleado[] listado) {
		double resultado = 0;
		for (int i = 0; i < listado.length; i++) {
			resultado = resultado + calcularSueldoEmpleado(listado[i]);
		}
		return resultado;
	}
}
