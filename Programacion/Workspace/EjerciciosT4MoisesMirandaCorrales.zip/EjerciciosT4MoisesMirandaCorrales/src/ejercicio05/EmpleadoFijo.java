package ejercicio05;

public class EmpleadoFijo extends Empleado{
	
	private double impuestos;//le quita un % de impuestos 
	
	
	
	public EmpleadoFijo(String nombre, double sueldoB, double recaudadoVentas, int nEmpleado, double impuestos) {
		super(nombre, sueldoB, recaudadoVentas, nEmpleado);
		this.impuestos = impuestos;
	}

	public double getImpuestos() {
		return impuestos;
	}

	public void setImpuestos(double impuestos) {
		this.impuestos = impuestos;
	}

	@Override
	public String toString() {
		return "EmpleadoFijo [impuestos=" + impuestos + "]";
	}
	
	public double calcularSueldo () {
		int den = 100;
		return getSueldoB() - (getSueldoB() * impuestos / den);
	}
	

}