package ejercicio05;

public abstract class Empleado {
	
	private String nombre;
	private double sueldoB;
	private double recaudadoVentas;
	private int nEmpleado;
	
	public Empleado(String nombre, double sueldoB, double recaudadoVentas, int nEmpleado) {
		super();
		this.nombre = nombre;
		this.sueldoB = sueldoB;
		this.recaudadoVentas = recaudadoVentas;
		this.nEmpleado = nEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldoB() {
		return sueldoB;
	}

	public void setSueldoB(double sueldoB) {
		this.sueldoB = sueldoB;
	}

	public double getRecaudadoVentas() {
		return recaudadoVentas;
	}

	public void setRecaudadoVentas(double recaudadoVentas) {
		this.recaudadoVentas = recaudadoVentas;
	}

	public int getnEmpleado() {
		return nEmpleado;
	}

	public void setnEmpleado(int nEmpleado) {
		this.nEmpleado = nEmpleado;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", sueldoB=" + sueldoB + ", recaudadoVentas=" + recaudadoVentas
				+ ", nEmpleado=" + nEmpleado + "]";
	}
	
	
	public abstract double calcularSueldo ();
	
	
}
