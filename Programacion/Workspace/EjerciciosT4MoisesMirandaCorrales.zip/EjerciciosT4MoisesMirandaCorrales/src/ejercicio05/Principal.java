package ejercicio05;



public class Principal {

	public static void main(String[] args) {
		
		double felicidades = 500;
		int empleadoAComision = 1;
		
		Empleado lista []= new Empleado [4];
		
		lista[0]= new EmpleadoAComision ("Pepe", 300, 80,1,10);
		lista[1]= new EmpleadoFijo ("Isabel Mar�a",1000,120,2, 20);
		lista[2]= new EmpleadoFijo ("Antonio y Maria", 1000, 30,2,20);
		lista[3]= new EmpleadoAComision ("Mois�s", 950, 220,1,10);
		
		Oficina f = new Oficina ();
		for (int i=0; i< lista.length;i++){
			System.out.printf("El sueldo de "+ lista[i].getNombre() + " es de: %.2f \n",f.calcularSueldoEmpleado(lista[i]));
			if (f.calcularSueldoEmpleado(lista[i]) > felicidades && lista[i].getnEmpleado() == empleadoAComision) {
				System.out.println("Felicidades " + lista[i].getNombre());
			}
			System.out.println("---------------------------------------------------");
			}
			System.out.printf("La suma de todos los sueldos es: %.2f", f.sumarSueldos(lista));
			
			

	}

}
