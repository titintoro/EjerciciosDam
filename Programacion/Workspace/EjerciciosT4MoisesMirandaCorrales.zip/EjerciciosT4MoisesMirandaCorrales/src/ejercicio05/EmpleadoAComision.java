package ejercicio05;

public class EmpleadoAComision extends Empleado {
	
	double incentivo; //un porcentaje de las ventas realizadas en un mes sumado a su sueldo base

	public EmpleadoAComision(String nombre, double sueldoB, double recaudadoVentas, int nEmpleado, double incentivo) {
		super(nombre, sueldoB, recaudadoVentas, nEmpleado);
		this.incentivo = incentivo;
	}

	public double getIncentivo() {
		return incentivo;
	}

	public void setIncentivo(double incentivo) {
		this.incentivo = incentivo;
	}

	@Override
	public String toString() {
		return "EmpleadoAComision [incentivo=" + incentivo + "]";
	}
	
	
	public double calcularSueldo () {
		int den = 100;
		return getSueldoB() + (getRecaudadoVentas()*incentivo / den);
	}
}
