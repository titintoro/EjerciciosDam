package ejercicio04;

public class Principal {

	public static void main(String[] args) {
		
		Producto p1= new Alimentacion ("Lechuga", 1.20, 2.00, 3, true);
		Producto p2= new Alimentacion ("Tomates", 1.70, 2.00, 6, true);
		Producto p3= new Alimentacion ("Leche", 0.80, 1.00, 10, true);
		Producto p4= new Electronica ("Tablet", 200.0, 250.00, true,10);
		Producto p5= new Electronica ("Monitor", 200.0, 250.00, false,10);
		Producto p6= new Electronica ("M�vil", 120.50, 130.00, true,10);
		
		LineaDeVenta lv1 = new LineaDeVenta (2, p1);
		LineaDeVenta lv2 = new LineaDeVenta (3, p2);
		LineaDeVenta lv3 = new LineaDeVenta (6, p3);
		LineaDeVenta lv4 = new LineaDeVenta (6, p4);
		LineaDeVenta lv5 = new LineaDeVenta (6, p5);
		LineaDeVenta lv6 = new LineaDeVenta (6, p6);
		
		LineaDeVenta listado []= {lv1,lv2,lv3,lv4,lv5,lv6};
		
		
		Venta v = new Venta (listado);
		
		double descuento = 5;
		int topeDias = 5;
		double precioSeguro = 50;
		
		System.out.println(v.calcularTotalVenta(descuento, topeDias, precioSeguro));
		

	}

}
