package ejercicio04;

public abstract class Producto {
	
	private String nombre;
	private double precioBase;
	private double pvp;
	
	
	//M�todos
	
	public Producto(String nombre, double precioBase, double pvp) {
		super();
		this.nombre = nombre;
		this.precioBase = precioBase;
		this.pvp = pvp;
	}
	
	
	
	// Getters and Setters

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioBase() {
		return precioBase;
	}

	public void setPrecioBase(double precioBase) {
		this.precioBase = precioBase;
	}

	public double getPvp() {
		return pvp;
	}

	public void setPvp(double pvp) {
		this.pvp = pvp;
	}
	
	// toString

	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", precioBase=" + precioBase + ", pvp=" + pvp + "]";
	}
	
	
	public abstract double calcularPvp (double descuento, int topeDias, double precioSeguro);
	
}
