package ejercicio04;

public class Electronica extends Producto {
	
	private boolean seguro;
	private double impuesto;
	
	
	
	
	public Electronica(String nombre, double precioBase, double pvp, boolean seguro, double impuesto) {
		super(nombre, precioBase, pvp);
		this.seguro = seguro;
		this.impuesto = impuesto;
	}


	public double calcularPvp (double descuento, int topeDias, double precioSeguro) {
		
		double resultado = 0;
		int den = 0;
		
		if(seguro == true) {
			resultado = getPvp() + precioSeguro;	
		}
		
		return resultado + resultado * impuesto / den;
		
		
	}
}
