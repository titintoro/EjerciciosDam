package ejercicio04;

import java.util.Arrays;

public class Venta {
	
	private LineaDeVenta [] listado;

	public Venta(LineaDeVenta[] listado) {
		super();
		this.listado = listado;
	}
	
	public Venta() {
		listado = new LineaDeVenta [20];
	}

	
	public LineaDeVenta[] getListado() {
		return listado;
	}

	public void setListado(LineaDeVenta[] listado) {
		this.listado = listado;
	}

	
	@Override
	public String toString() {
		return "Venta [listado=" + Arrays.toString(listado) + "]";
	}
	
	
	public double calcularTotalVenta(double descuento, int topeDias, double precioSeguro) {

		double resultado = 0;
		
		for (int i = 0; i < listado.length; i++) {
			resultado = resultado + listado[i].calcularSubtotal(descuento, topeDias, precioSeguro);
		}
		return resultado;
	}
	
}
