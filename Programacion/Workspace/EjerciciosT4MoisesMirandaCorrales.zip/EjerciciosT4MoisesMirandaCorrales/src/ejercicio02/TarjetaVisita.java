package ejercicio02;

public class TarjetaVisita extends Documento {
	
	public void ImprimirDocumento() {
		
		System.out.println("-------------------------------------------------------------\n");
		System.out.println("\t\t\t SALESIANOS TRIANA\n");
		System.out.println("-------------------------------------------------------------\n");
		System.out.println("\t\t DESARROLLO DE PLICAIONES MULTIPLATAFORMAS\n");
		System.out.println("-------------------------------------------------------------");
	}

}
