package ejercicio02;

public abstract class Documento {
	
	public abstract void ImprimirDocumento();
	

}
