package ejercicio02;

public class Carta extends Documento{
	
	public void ImprimirDocumento () {
		
		System.out.println("\t\tSALESIANOS TRIANA");
		System.out.println("------------------------------------------------------");
		System.out.println("NOMBRE:");
		System.out.println("TEL�OFONO:");
		System.out.println("DIRECCI�N:");
		System.out.println("DESTINATARIO:");
		System.out.println("------------------------------------------------------\n\n\n\n");
		System.out.println("FECHA:");
		System.out.println("FIRMA:");
		
	}
}
