package ejercicioCuentas;

public class CuentaCorriente extends Cuenta {
	
	private int edad;
	
	public CuentaCorriente(String nombre, double saldo, int edad) {
		super(nombre, saldo);
		this.edad = edad;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	
	

	@Override
	public String toString() {
		return "CuentaCorriente edad=" + edad + ", Nombre=" + getNombre() + ", Saldo=" + getSaldo();
				
	}


	public double calcularComision () {
		
		int minEdad = 25;
		double porcentaje = 1.5;
		double den = 100;
		
		if (edad < minEdad) {
			return 0;
		}else {
			return super.getSaldo() * porcentaje / den;
		}
	}
	public double calcularCosteMantCuenta () {
		
		int minEdad = 25;
		double mantCuenta = 25;
		
		if (edad < minEdad) {
			return 0;
		}else {
			return mantCuenta;
		}
		
	}
	
	
}
