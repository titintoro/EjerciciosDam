package ejercicioCuentas;


public class Principal {

	public static void main(String[] args) {
		
		Cuenta lista []= new Cuenta [4];
		
		lista[0]= new CuentaCorriente ("Pepe", 300, 30);
		lista[1]= new CuentaAhorro ("Fran",1600,1);
		lista[2]= new CuentaAhorro ("Antonio y Maria", 6000, 2);
		lista[3]= new CuentaCorriente ("Mois�s", 40, 22);
		
		for (int i=0; i<lista.length;i++){
			System.out.println(lista[i].toString());
			}
			
			Banco b= new Banco ();
			for (int i=0; i< lista.length;i++){
			System.out.printf("La comisi�n de la cuenta "+ (i+1)+ " es de: %.2f \n",b.calcularComisionDeUnaCuenta(lista[i]));
			}
			System.out.printf("La suma de todas las comisiones es: %.2f", b.sumarComisiones(lista));
			

	}

}
