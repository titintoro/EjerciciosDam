package ejercicioCuentas;

public class CuentaAhorro extends Cuenta {
	
	private int titulares;

	public CuentaAhorro(String nombre, double saldo, int titulares) {
		super(nombre, saldo);
		this.titulares = titulares;
	}

	public int getTitulares() {
		return titulares;
	}

	public void setTitulares(int titulares) {
		this.titulares = titulares;
	}

	
	
	
	
	@Override
	public String toString() {
		return "CuentaAhorro titulares=" + titulares + ", Nombre=" + getNombre() + ", Saldo=" + getSaldo();
	}

	public double calcularComision () {
		int mintitulares = 1;
		double porcentaje = 0.5;
		double den = 100;
		
		if (titulares < mintitulares) {
			return 0;
		}else {
			return super.getSaldo() * porcentaje / den;
		}
	}
	public double calcularCosteMantCuenta () {
		double mantCuenta = 35;
		
		return mantCuenta;
	}
}
