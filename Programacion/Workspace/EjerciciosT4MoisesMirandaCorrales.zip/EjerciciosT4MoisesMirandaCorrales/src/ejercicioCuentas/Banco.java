package ejercicioCuentas;


public class Banco {
	
	public double calcularComisionDeUnaCuenta (Cuenta c) {
		
		return c.calcularComision();
	}
	
	public double sumarComisiones(Cuenta[] listado) {
		double resultado = 0;
		for (int i = 0; i < listado.length; i++) {
			resultado = resultado + calcularComisionDeUnaCuenta(listado[i]);
		}
		return resultado;
	}


}
