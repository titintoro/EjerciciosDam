package Ejercicio5U2;

import java.util.Random;

public class Principal {

	public static void main(String[] args) {
				//Programa que:
				//Solicite al usuario que introduzca por teclado el tama�o del array
				//Declarar y definir el array de enteros
				//Rellenar el array con n� aleatorios entre dos valores escogidos por el usuario
				//Imprimir suma de todos los elementos
				//Mostrar menor y mayor del array
				
				//Definicion de variables
				int tam = 0;
				int hasta;
				int desde;
				int [] num;
				Random random = new Random(System.nanoTime());;
				int elem;
				int suma = 0;
				int menor = -1;
				int mayor = -1;
				
				//Solicite al usuario que introduzca por teclado el tama�o del array
				System.out.println("Introduzca el tama�o");
				tam=Leer.datoInt();	
				
				//Declarar y definir el array de enteros
				num=new int [tam];
				
				//Rellenar el array con n� aleatorios entre dos valores escogidos por el usuario y suma de los elementos
				System.out.println("Introduzca hasta y desde");
				System.out.println("hasta: ");
				hasta=Leer.datoInt();
				System.out.println("desde: ");
				desde=Leer.datoInt();
	
				
				//Para rellenar el array
				for (int i=0; i<num.length;i++) {
					
					elem = random.nextInt(hasta-desde+1)+desde;
					num[i] = elem;
				}
				
				//Sumar elementos
				for (int i = 0; i < num.length; i++) {
					suma+= num[i];
				}
					
				System.out.println("La suma de todo es: " + suma);
				
				//Para mostrar
				for (int i = 0; i < num.length; i++) {
					System.out.print("\t" +num[i]);
				}
				
				System.out.println();
				//Para comprobar el mayor y menor
				for (int i = 0; i < num.length; i++) {
						
					if (i == 0) {
						menor = num[i];
						mayor = num[i];
					}else {
						if (num[i] > mayor) {
							mayor = num[i];
						}
						if (num[i] < menor) {
							menor = num[i];
						}
					}
				}
			
				//Mostrar menor y mayor del array
				System.out.println("El n�mero mayor es "+ mayor);
				System.out.println("El n�mero menor es "+ menor);
				
				
	}

}
