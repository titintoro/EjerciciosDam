package ejemplo2;

public class Carta extends Documento{

	public void ImprimirDocumento () {
		 System.out.println("A d�a 21 de Marzo de 2021");
	}
}
	

