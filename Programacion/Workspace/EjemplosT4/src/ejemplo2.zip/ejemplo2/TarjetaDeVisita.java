package ejemplo2;

public class TarjetaDeVisita extends Documento{

	public void ImprimirDocumento () {
		 System.out.println("Permiso de visita oficial.");
	}
}
