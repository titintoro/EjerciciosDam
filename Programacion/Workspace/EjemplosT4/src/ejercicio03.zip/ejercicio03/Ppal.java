package ejercicio03;

public class Ppal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Coche c = new Coche ();
		
	}

}
